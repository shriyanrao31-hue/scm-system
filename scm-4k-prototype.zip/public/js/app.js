/**
 * Main Single Page Application (SPA) Controller
 * Connects REST APIs (PHP 8.x) and Socket.io Telemetry Radar to the UI.
 * Handles stock deduction simulation, PO kanban transitions, live tickers, and audio-visual cues.
 */

document.addEventListener('DOMContentLoaded', () => {
  console.log('⚡ SCM 4K Command Center SPA Booting...');

  // Configuration options
  const API_BASE = window.SCM_CONFIG?.API_BASE || '';
  
  // State
  let inventoryData = [];
  let shipmentsData = [];
  let poData = [];
  let trackerMap = null;
  let chartManager = null;
  let telemetryRadar = null;

  // 1. Initialize Clock
  function startHudClock() {
    const clockEl = document.getElementById('hud-live-clock');
    const updateTime = () => {
      const now = new Date();
      if (clockEl) {
        clockEl.innerText = now.toUTCString().replace('GMT', 'UTC');
      }
    };
    updateTime();
    setInterval(updateTime, 1000);
  }

  // 2. Load Strategic Warehouses
  const strategicWarehouses = [
    { code: 'ORD-01', name: 'Chicago Apex Hub', city: 'Chicago', country: 'USA', lat: 41.9742, lng: -87.9073 },
    { code: 'DFW-02', name: 'Dallas Fort Worth SuperCenter', city: 'Dallas', country: 'USA', lat: 32.8998, lng: -97.0403 },
    { code: 'LAX-03', name: 'Ontario Inland Depot', city: 'Ontario', country: 'USA', lat: 34.0537, lng: -117.5982 },
    { code: 'EWR-04', name: 'Newark Port Mega-Facility', city: 'Newark', country: 'USA', lat: 40.6895, lng: -74.1745 },
    { code: 'ATL-05', name: 'Atlanta Gateway Fulfillment', city: 'Atlanta', country: 'USA', lat: 33.6407, lng: -84.4277 },
    { code: 'SEA-06', name: 'Seattle North Intermodal Hub', city: 'Seattle', country: 'USA', lat: 47.4502, lng: -122.3088 },
    { code: 'DEN-07', name: 'Denver Rockies Depot', city: 'Denver', country: 'USA', lat: 39.8561, lng: -104.6737 },
    { code: 'MEM-08', name: 'Memphis Mid-South CrossDock', city: 'Memphis', country: 'USA', lat: 35.0424, lng: -89.9767 }
  ];

  // 3. Initialize GIS Map & Charts
  try {
    trackerMap = new FleetTrackerMap('gis-map');
    trackerMap.plotWarehouses(strategicWarehouses);
  } catch (e) {
    console.error('Failed to init GIS Map:', e);
  }

  try {
    chartManager = new InventoryTelemetryCharts();
  } catch (e) {
    console.error('Failed to init Charts:', e);
  }

  // 4. Initialize WebSocket Telemetry Radar
  telemetryRadar = new TelemetryRadar();

  telemetryRadar.on('telemetry:update', (telemetry) => {
    if (trackerMap) trackerMap.handleLiveTelemetry(telemetry);
    logEventFeed(`GPS [${telemetry.tracking_number}]: Lat ${telemetry.lat}, Lng ${telemetry.lng} @ ${telemetry.speed} mph`);
  });

  telemetryRadar.on('inventory:alert', (alert) => {
    console.warn('⚠️ Real-Time Stock Breach Received:', alert);
    logEventFeed(`STOCK BREACH: ${alert.sku} @ ${alert.warehouse_code} dropped to ${alert.current_qty} units!`, true);
    // Refresh inventory list
    fetchInventory();
  });

  telemetryRadar.on('po:status_change', (poEvent) => {
    console.log('📦 Real-Time PO Status Update:', poEvent);
    logEventFeed(`PO UPDATE: ${poEvent.po_number} -> ${poEvent.new_status || poEvent.status} ($${Number(poEvent.total_amount).toLocaleString()})`);
    fetchPurchaseOrders();
  });

  // 5. REST API: Fetch Inventory
  async function fetchInventory() {
    try {
      const res = await fetch(`${API_BASE}/api/inventory.php?action=list&limit=50`);
      if (!res.ok) throw new Error('Failed to load inventory API');
      const data = await res.json();
      if (data.success && Array.isArray(data.inventory)) {
        inventoryData = data.inventory;
        renderInventoryTable(inventoryData);
        if (chartManager) chartManager.updateStockMetrics(inventoryData);
        updateInventoryCounters(inventoryData);
      }
    } catch (err) {
      console.warn('API fetchInventory failed, trying local fallback:', err);
      renderMockInventory();
    }
  }

  // 6. REST API: Fetch Shipments
  async function fetchShipments() {
    try {
      const res = await fetch(`${API_BASE}/api/shipments.php?action=active&limit=30`);
      if (!res.ok) throw new Error('Failed to load shipments API');
      const data = await res.json();
      if (data.success && Array.isArray(data.shipments)) {
        shipmentsData = data.shipments;
        if (trackerMap) trackerMap.loadInitialShipments(shipmentsData);
        document.getElementById('stat-active-trucks').innerText = shipmentsData.length;
      }
    } catch (err) {
      console.warn('API fetchShipments failed, plotting simulated defaults:', err);
    }
  }

  // 7. REST API: Fetch Purchase Orders (Kanban Pipeline)
  async function fetchPurchaseOrders() {
    try {
      const res = await fetch(`${API_BASE}/api/purchase_orders.php?action=list&limit=60`);
      if (!res.ok) throw new Error('Failed to load purchase orders API');
      const data = await res.json();
      if (data.success && data.kanban) {
        poData = data.orders;
        renderKanbanBoard(data.kanban);
        updatePoCounters(poData);
      }
    } catch (err) {
      console.warn('API fetchPurchaseOrders failed:', err);
    }
  }

  // Render Inventory Table
  function renderInventoryTable(items) {
    const tbody = document.getElementById('inventory-table-body');
    if (!tbody) return;

    tbody.innerHTML = '';
    items.forEach((item) => {
      const tr = document.createElement('tr');
      let badgeClass = 'badge-optimal';
      if (item.stock_status === 'LOW_STOCK') badgeClass = 'badge-low';
      if (item.stock_status === 'CRITICAL_REORDER' || item.stock_status === 'OUT_OF_STOCK') badgeClass = 'badge-critical';

      tr.innerHTML = `
        <td style="font-family: var(--font-hud); font-weight: bold; color: var(--accent-cyan);">${item.sku}</td>
        <td>${item.product_name}</td>
        <td style="font-family: var(--font-hud);">${item.warehouse_code}</td>
        <td style="font-family: var(--font-hud); font-weight: 700;">${item.quantity_on_hand}</td>
        <td style="font-family: var(--font-hud); color: var(--accent-amber);">${item.reorder_point}</td>
        <td style="font-family: var(--font-hud); color: var(--accent-emerald);">${item.economic_order_qty}</td>
        <td><span class="badge ${badgeClass}">${item.stock_status}</span></td>
        <td>
          <button class="hud-btn hud-btn-danger btn-deduct" data-pid="${item.product_id}" data-wid="${item.warehouse_id}">
            ⚡ Deduct 25
          </button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    // Attach deduction click triggers
    document.querySelectorAll('.btn-deduct').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const pid = e.target.getAttribute('data-pid');
        const wid = e.target.getAttribute('data-wid');
        simulateStockDeduction(pid, wid, 25);
      });
    });
  }

  // Render Kanban Columns
  function renderKanbanBoard(kanban) {
    const columns = ['Draft', 'Issued', 'In Transit', 'Received'];
    columns.forEach(col => {
      const colContainer = document.getElementById(`kanban-cards-${col.toLowerCase().replace(' ', '-')}`);
      if (!colContainer) return;

      colContainer.innerHTML = '';
      const orders = kanban[col] || [];
      const countBadge = document.getElementById(`kanban-count-${col.toLowerCase().replace(' ', '-')}`);
      if (countBadge) countBadge.innerText = orders.length;

      orders.forEach(po => {
        const card = document.createElement('div');
        card.className = 'kanban-card';
        card.innerHTML = `
          <div class="po-header-line">
            <span class="po-number-title">${po.po_number}</span>
            <span class="hud-badge">${po.trigger_type === 'AUTOMATED_ROP' ? 'AUTO ROP' : 'MANUAL'}</span>
          </div>
          <div class="po-supplier-txt">${po.supplier_name} → ${po.warehouse_code}</div>
          <div class="po-footer-line">
            <span>Items: ${po.item_count || 1}</span>
            <span style="color: var(--accent-cyan); font-weight: bold;">$${Number(po.total_amount).toLocaleString()}</span>
          </div>
        `;

        card.addEventListener('click', () => {
          advancePoStatusPrompt(po);
        });

        colContainer.appendChild(card);
      });
    });
  }

  // Stock Deduction Action
  async function simulateStockDeduction(productId, warehouseId, qty = 25) {
    try {
      logEventFeed(`Deducting ${qty} units from Product #${productId} @ Warehouse #${warehouseId}...`);
      const res = await fetch(`${API_BASE}/api/inventory.php?action=deduct`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ product_id: parseInt(productId), warehouse_id: parseInt(warehouseId), quantity: qty })
      });

      const result = await res.json();
      if (result.success) {
        logEventFeed(`Stock deducted successfully: New Qty: ${result.inventory.new_quantity} [${result.inventory.stock_status}]`);
        if (result.automated_po) {
          logEventFeed(`🚨 AUTOMATED ROP TRIGGER: PO Created ${result.automated_po.po_number} for $${result.automated_po.total_amount}!`, true);
        }
        fetchInventory();
        fetchPurchaseOrders();
      } else {
        alert(`Deduction failed: ${result.error}`);
      }
    } catch (err) {
      console.error('Stock deduction error:', err);
    }
  }

  // PO State Transition Helper
  async function advancePoStatusPrompt(po) {
    const nextStates = {
      'Draft': 'Issued',
      'Issued': 'In Transit',
      'In Transit': 'Received',
      'Received': null
    };

    const next = nextStates[po.status];
    if (!next) {
      alert(`PO ${po.po_number} is already fully Received and closed.`);
      return;
    }

    if (confirm(`Advance Purchase Order ${po.po_number} from "${po.status}" to "${next}"?`)) {
      try {
        const res = await fetch(`${API_BASE}/api/purchase_orders.php?action=update_status`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: po.id, status: next })
        });
        const resp = await res.json();
        if (resp.success) {
          logEventFeed(`PO Status Changed: ${po.po_number} -> ${next}`);
          fetchPurchaseOrders();
          fetchInventory();
        }
      } catch (e) {
        console.error('Failed to update PO status:', e);
      }
    }
  }

  // Update HUD Header Counters
  function updateInventoryCounters(items) {
    const criticalCount = items.filter(i => i.stock_status === 'CRITICAL_REORDER' || i.stock_status === 'OUT_OF_STOCK').length;
    const criticalEl = document.getElementById('stat-critical-skus');
    if (criticalEl) criticalEl.innerText = criticalCount;

    const totalVal = items.reduce((acc, curr) => acc + (curr.quantity_on_hand * (curr.unit_price || 25)), 0);
    const valEl = document.getElementById('stat-inventory-val');
    if (valEl) valEl.innerText = `$${(totalVal / 1000).toFixed(1)}k`;
  }

  function updatePoCounters(orders) {
    const activePos = orders.filter(p => p.status === 'Draft' || p.status === 'Issued' || p.status === 'In Transit').length;
    const poEl = document.getElementById('stat-active-pos');
    if (poEl) poEl.innerText = activePos;
  }

  // Event Feed Logger
  function logEventFeed(message, isAlert = false) {
    const feed = document.getElementById('hud-event-feed');
    if (!feed) return;

    const entry = document.createElement('div');
    entry.className = `event-entry ${isAlert ? 'alert-danger' : ''}`;
    const time = new Date().toTimeString().split(' ')[0];
    entry.innerHTML = `<span class="event-time">[${time}]</span> <span>${message}</span>`;
    feed.prepend(entry);

    if (feed.children.length > 50) {
      feed.removeChild(feed.lastChild);
    }
  }

  // Quick action: Simulate rapid deduction on first SKU
  document.getElementById('btn-quick-deduct')?.addEventListener('click', () => {
    if (inventoryData.length > 0) {
      const target = inventoryData[0];
      simulateStockDeduction(target.product_id, target.warehouse_id, 30);
    }
  });

  // Fallback Mock Inventory for instant preview if DB offline
  function renderMockInventory() {
    const sampleItems = [
      { product_id: 1, warehouse_id: 1, sku: 'SKU-SEM-1001', product_name: 'ARM-M4 High-Precision MCU', warehouse_code: 'WH-ORD-01', quantity_on_hand: 18, reorder_point: 85, economic_order_qty: 120, stock_status: 'CRITICAL_REORDER', unit_price: 14.50 },
      { product_id: 2, warehouse_id: 2, sku: 'SKU-LIT-1002', product_name: 'LiFePO4 Modular 48V Battery', warehouse_code: 'WH-DFW-02', quantity_on_hand: 52, reorder_point: 60, economic_order_qty: 80, stock_status: 'LOW_STOCK', unit_price: 890.00 },
      { product_id: 3, warehouse_id: 3, sku: 'SKU-OPT-1003', product_name: 'Solid-State Lidar 120m Array', warehouse_code: 'WH-LAX-03', quantity_on_hand: 140, reorder_point: 45, economic_order_qty: 90, stock_status: 'OPTIMAL', unit_price: 620.00 },
      { product_id: 4, warehouse_id: 4, sku: 'SKU-ROB-1004', product_name: 'Brushless DC Servo Actuator', warehouse_code: 'WH-EWR-04', quantity_on_hand: 9, reorder_point: 40, economic_order_qty: 60, stock_status: 'CRITICAL_REORDER', unit_price: 112.00 }
    ];
    inventoryData = sampleItems;
    renderInventoryTable(sampleItems);
    if (chartManager) chartManager.updateStockMetrics(sampleItems);
    updateInventoryCounters(sampleItems);
  }

  // Boot sequence
  startHudClock();
  fetchInventory();
  fetchShipments();
  fetchPurchaseOrders();
  logEventFeed('SCM 4K HUD Command Center successfully initialized.');
});
