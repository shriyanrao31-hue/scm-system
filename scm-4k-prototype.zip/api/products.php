<?php
/**
 * Master Catalog & Inventory Analytics API
 * Handles products query, filtering, and mathematical calculations:
 * - Daily Demand Rate
 * - Supplier Lead Time
 * - Reorder Point: ROP = (daily_demand_rate * supplier_lead_time_days) + safety_stock
 * - Economic Order Quantity: EOQ = sqrt((2 * annual_demand * order_cost) / holding_cost)
 */

require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $search = $_GET['search'] ?? '';
    $category = $_GET['category'] ?? '';
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 100;
    $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;

    $query = "
        SELECT 
            p.id,
            p.sku,
            p.name,
            p.category,
            p.unit_price,
            p.daily_demand_rate,
            p.order_cost,
            p.holding_cost_rate,
            p.safety_stock,
            p.supplier_id,
            s.name AS supplier_name,
            s.code AS supplier_code,
            s.lead_time_days AS supplier_lead_time_days,
            s.reliability_score,
            COALESCE(SUM(i.quantity_on_hand), 0) AS total_on_hand,
            COALESCE(SUM(i.quantity_reserved), 0) AS total_reserved,
            COUNT(i.id) AS warehouse_count
        FROM products p
        JOIN suppliers s ON p.supplier_id = s.id
        LEFT JOIN inventory i ON p.id = i.product_id
        WHERE 1=1
    ";

    $params = [];
    if (!empty($search)) {
        $query .= " AND (p.sku LIKE :search OR p.name LIKE :search)";
        $params['search'] = "%{$search}%";
    }
    if (!empty($category)) {
        $query .= " AND p.category = :category";
        $params['category'] = $category;
    }

    $query .= " GROUP BY p.id ORDER BY p.id ASC LIMIT :limit OFFSET :offset";

    $stmt = $pdo->prepare($query);
    foreach ($params as $k => $v) {
        $stmt->bindValue(":{$k}", $v);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll();

    // Perform live analytical evaluations
    $results = array_map(function($row) {
        $leadTime = (int)$row['supplier_lead_time_days'];
        $dailyDemand = (float)$row['daily_demand_rate'];
        $safetyStock = (int)$row['safety_stock'];
        $unitPrice = (float)$row['unit_price'];
        $orderCost = (float)$row['order_cost'];
        $holdingRate = (float)$row['holding_cost_rate'];

        // Mathematical Calculations
        // 1. Reorder Point (ROP) = (daily_demand_rate * lead_time_days) + safety_stock
        $calculatedRop = round(($dailyDemand * $leadTime) + $safetyStock);

        // 2. Annual Demand (D) = daily_demand_rate * 365
        $annualDemand = $dailyDemand * 365;

        // 3. Unit Annual Holding Cost (H) = unit_price * holding_cost_rate
        $unitHoldingCost = max($unitPrice * $holdingRate, 1.0);

        // 4. Economic Order Quantity (EOQ) = sqrt((2 * D * S) / H)
        $calculatedEoq = max(round(sqrt((2 * $annualDemand * $orderCost) / $unitHoldingCost)), 25);

        $totalOnHand = (int)$row['total_on_hand'];

        // Health Status Indicator
        $health = 'OPTIMAL';
        if ($totalOnHand <= 0) {
            $health = 'OUT_OF_STOCK';
        } elseif ($totalOnHand < ($calculatedRop * 0.7)) {
            $health = 'CRITICAL_REORDER';
        } elseif ($totalOnHand <= $calculatedRop) {
            $health = 'LOW_STOCK';
        }

        return [
            'id' => (int)$row['id'],
            'sku' => $row['sku'],
            'name' => $row['name'],
            'category' => $row['category'],
            'unit_price' => $unitPrice,
            'daily_demand_rate' => $dailyDemand,
            'supplier' => [
                'id' => (int)$row['supplier_id'],
                'name' => $row['supplier_name'],
                'code' => $row['supplier_code'],
                'lead_time_days' => $leadTime,
                'reliability_score' => (float)$row['reliability_score']
            ],
            'inventory_summary' => [
                'total_on_hand' => $totalOnHand,
                'total_reserved' => (int)$row['total_reserved'],
                'warehouse_count' => (int)$row['warehouse_count'],
                'calculated_rop' => $calculatedRop,
                'calculated_eoq' => $calculatedEoq,
                'health_status' => $health
            ]
        ];
    }, $rows);

    echo json_encode([
        'success' => true,
        'count' => count($results),
        'products' => $results
    ]);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
