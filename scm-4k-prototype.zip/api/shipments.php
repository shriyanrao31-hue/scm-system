<?php
/**
 * Shipments & GIS Tracking API
 * Provides active fleet locations, route geometries, and shipment details
 */

require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'active';

if ($method === 'GET' && ($action === 'active' || $action === 'list')) {
    $carrier = $_GET['carrier'] ?? null;
    $status = $_GET['status'] ?? null;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 60;

    $query = "
        SELECT 
            s.id,
            s.tracking_number,
            s.carrier,
            s.po_id,
            s.status,
            s.current_latitude,
            s.current_longitude,
            s.current_speed_mph,
            s.current_heading_deg,
            s.eta_timestamp,
            s.route_geometry,
            s.updated_at,
            w1.name AS origin_name,
            w1.code AS origin_code,
            w1.latitude AS origin_lat,
            w1.longitude AS origin_lng,
            w2.name AS destination_name,
            w2.code AS destination_code,
            w2.latitude AS destination_lat,
            w2.longitude AS destination_lng,
            po.po_number,
            po.total_amount AS po_amount
        FROM shipments s
        JOIN warehouses w1 ON s.origin_warehouse_id = w1.id
        JOIN warehouses w2 ON s.destination_warehouse_id = w2.id
        LEFT JOIN purchase_orders po ON s.po_id = po.id
        WHERE 1=1
    ";

    $params = [];
    if (!empty($carrier)) {
        $query .= " AND s.carrier = :carrier";
        $params['carrier'] = $carrier;
    }
    if (!empty($status)) {
        $query .= " AND s.status = :status";
        $params['status'] = $status;
    }

    $query .= " ORDER BY s.updated_at DESC LIMIT :limit";

    $stmt = $pdo->prepare($query);
    foreach ($params as $k => $v) {
        $stmt->bindValue(":{$k}", $v);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll();

    $shipments = array_map(function($row) {
        $decodedRoute = null;
        if (!empty($row['route_geometry'])) {
            $decodedRoute = is_string($row['route_geometry']) 
                ? json_decode($row['route_geometry'], true) 
                : $row['route_geometry'];
        }

        return [
            'id' => (int)$row['id'],
            'tracking_number' => $row['tracking_number'],
            'carrier' => $row['carrier'],
            'status' => $row['status'],
            'po_number' => $row['po_number'],
            'po_amount' => $row['po_amount'] ? (float)$row['po_amount'] : null,
            'current_position' => [
                'lat' => (float)$row['current_latitude'],
                'lng' => (float)$row['current_longitude'],
                'speed_mph' => (float)$row['current_speed_mph'],
                'heading_deg' => (float)$row['current_heading_deg']
            ],
            'origin' => [
                'code' => $row['origin_code'],
                'name' => $row['origin_name'],
                'lat' => (float)$row['origin_lat'],
                'lng' => (float)$row['origin_lng']
            ],
            'destination' => [
                'code' => $row['destination_code'],
                'name' => $row['destination_name'],
                'lat' => (float)$row['destination_lat'],
                'lng' => (float)$row['destination_lng']
            ],
            'eta' => $row['eta_timestamp'],
            'route_geometry' => $decodedRoute
        ];
    }, $rows);

    echo json_encode([
        'success' => true,
        'count' => count($shipments),
        'shipments' => $shipments
    ]);
    exit;
}

http_response_code(400);
echo json_encode(['success' => false, 'error' => 'Invalid action.']);
