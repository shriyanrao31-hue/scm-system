<?php
/**
 * Purchase Orders & Pipeline Management API
 * Supports Kanban states: Draft -> Issued -> In Transit -> Received -> Cancelled
 * Automatically emits webhook events to Node.js when state transitions occur.
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/webhooks/notify_node.php';

header('Content-Type: application/json');

$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'list';

// 1. LIST PURCHASE ORDERS (For Kanban Pipeline)
if ($method === 'GET' && $action === 'list') {
    $status = $_GET['status'] ?? null;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 100;

    $query = "
        SELECT 
            po.id,
            po.po_number,
            po.status,
            po.total_amount,
            po.trigger_type,
            po.expected_delivery_date,
            po.created_at,
            po.updated_at,
            s.id AS supplier_id,
            s.name AS supplier_name,
            s.code AS supplier_code,
            s.lead_time_days,
            w.id AS warehouse_id,
            w.name AS warehouse_name,
            w.code AS warehouse_code,
            COUNT(poi.id) AS item_count
        FROM purchase_orders po
        JOIN suppliers s ON po.supplier_id = s.id
        JOIN warehouses w ON po.warehouse_id = w.id
        LEFT JOIN po_items poi ON po.id = poi.po_id
        WHERE 1=1
    ";

    $params = [];
    if (!empty($status)) {
        $query .= " AND po.status = :status";
        $params['status'] = $status;
    }

    $query .= " GROUP BY po.id ORDER BY po.updated_at DESC LIMIT :limit";

    $stmt = $pdo->prepare($query);
    foreach ($params as $k => $v) {
        $stmt->bindValue(":{$k}", $v);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    $orders = $stmt->fetchAll();

    // Group by status for Kanban Board representation
    $kanban = [
        'Draft' => [],
        'Issued' => [],
        'In Transit' => [],
        'Received' => [],
        'Cancelled' => []
    ];

    foreach ($orders as $order) {
        $st = $order['status'];
        if (isset($kanban[$st])) {
            $kanban[$st][] = $order;
        }
    }

    echo json_encode([
        'success' => true,
        'count' => count($orders),
        'orders' => $orders,
        'kanban' => $kanban
    ]);
    exit;
}

// 2. GET PURCHASE ORDER DETAIL WITH ITEMS
if ($method === 'GET' && $action === 'detail') {
    $poId = (int)($_GET['id'] ?? 0);
    if ($poId <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Valid PO id required.']);
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT 
            po.*,
            s.name AS supplier_name, s.code AS supplier_code, s.contact_email,
            w.name AS warehouse_name, w.code AS warehouse_code, w.city AS warehouse_city
        FROM purchase_orders po
        JOIN suppliers s ON po.supplier_id = s.id
        JOIN warehouses w ON po.warehouse_id = w.id
        WHERE po.id = :id
    ");
    $stmt->execute(['id' => $poId]);
    $po = $stmt->fetch();

    if (!$po) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Purchase order not found.']);
        exit;
    }

    $itemsStmt = $pdo->prepare("
        SELECT poi.*, p.sku, p.name AS product_name, p.category
        FROM po_items poi
        JOIN products p ON poi.product_id = p.id
        WHERE poi.po_id = :po_id
    ");
    $itemsStmt->execute(['po_id' => $poId]);
    $items = $itemsStmt->fetchAll();

    $po['items'] = $items;
    echo json_encode(['success' => true, 'purchase_order' => $po]);
    exit;
}

// 3. UPDATE PURCHASE ORDER STATUS (KANBAN TRANSITIONS)
if ($method === 'POST' && $action === 'update_status') {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $poId = (int)($input['id'] ?? 0);
    $newStatus = trim($input['status'] ?? '');

    $allowedStatuses = ['Draft', 'Issued', 'In Transit', 'Received', 'Cancelled'];
    if ($poId <= 0 || !in_array($newStatus, $allowedStatuses, true)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid ID or status value. Allowed: ' . implode(', ', $allowedStatuses)]);
        exit;
    }

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("
            SELECT po.*, s.name AS supplier_name, w.code AS warehouse_code, w.id AS warehouse_id
            FROM purchase_orders po
            JOIN suppliers s ON po.supplier_id = s.id
            JOIN warehouses w ON po.warehouse_id = w.id
            WHERE po.id = :id FOR UPDATE
        ");
        $stmt->execute(['id' => $poId]);
        $po = $stmt->fetch();

        if (!$po) {
            $pdo->rollBack();
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'PO not found.']);
            exit;
        }

        $oldStatus = $po['status'];
        $upd = $pdo->prepare("UPDATE purchase_orders SET status = :status, updated_at = NOW() WHERE id = :id");
        $upd->execute(['status' => $newStatus, 'id' => $poId]);

        // If status transitioned to 'Received', automatically replenish inventory
        if ($newStatus === 'Received' && $oldStatus !== 'Received') {
            $itemsStmt = $pdo->prepare("SELECT product_id, quantity FROM po_items WHERE po_id = :po_id");
            $itemsStmt->execute(['po_id' => $poId]);
            $items = $itemsStmt->fetchAll();

            foreach ($items as $item) {
                $replenishStmt = $pdo->prepare("
                    UPDATE inventory 
                    SET quantity_on_hand = quantity_on_hand + :qty,
                        stock_status = CASE 
                            WHEN (quantity_on_hand + :qty) > reorder_point THEN 'OPTIMAL'
                            ELSE 'LOW_STOCK'
                        END,
                        updated_at = NOW()
                    WHERE product_id = :pid AND warehouse_id = :wid
                ");
                $replenishStmt->execute([
                    'qty' => $item['quantity'],
                    'pid' => $item['product_id'],
                    'wid' => $po['warehouse_id']
                ]);
            }
        }

        $pdo->commit();

        // Broadcast to Node.js WebSocket Service
        $eventPayload = [
            'po_id' => $poId,
            'po_number' => $po['po_number'],
            'previous_status' => $oldStatus,
            'new_status' => $newStatus,
            'supplier_name' => $po['supplier_name'],
            'warehouse_code' => $po['warehouse_code'],
            'total_amount' => (float)$po['total_amount']
        ];
        notifyNodeService('po:status_change', $eventPayload);

        echo json_encode([
            'success' => true,
            'message' => "PO status updated to {$newStatus}",
            'data' => $eventPayload
        ]);
        exit;

    } catch (Exception $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to update status: ' . $e->getMessage()]);
        exit;
    }
}

http_response_code(400);
echo json_encode(['success' => false, 'error' => 'Unsupported action.']);
