<?php
/**
 * Inventory Management & Automated Reorder Point (ROP) Trigger Engine
 * Features:
 * - Query inventory per warehouse / SKU
 * - Real-time stock deduction
 * - Automatic ROP evaluation
 * - Automatic Draft Purchase Order generation upon stock breach
 * - Real-time Webhook dispatch to Node.js microservice
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/webhooks/notify_node.php';

header('Content-Type: application/json');

$pdo = Database::getConnection();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'list';

// 1. LIST INVENTORY WITH ANALYTICS
if ($method === 'GET' && $action === 'list') {
    $warehouseId = isset($_GET['warehouse_id']) ? (int)$_GET['warehouse_id'] : null;
    $statusFilter = $_GET['status'] ?? null;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 150;

    $query = "
        SELECT 
            i.id,
            i.product_id,
            i.warehouse_id,
            i.quantity_on_hand,
            i.quantity_reserved,
            i.reorder_point,
            i.economic_order_qty,
            i.stock_status,
            i.updated_at,
            p.sku,
            p.name AS product_name,
            p.category,
            p.unit_price,
            p.daily_demand_rate,
            w.name AS warehouse_name,
            w.code AS warehouse_code,
            w.city AS warehouse_city,
            s.id AS supplier_id,
            s.name AS supplier_name,
            s.lead_time_days
        FROM inventory i
        JOIN products p ON i.product_id = p.id
        JOIN warehouses w ON i.warehouse_id = w.id
        JOIN suppliers s ON p.supplier_id = s.id
        WHERE 1=1
    ";

    $params = [];
    if ($warehouseId) {
        $query .= " AND i.warehouse_id = :warehouse_id";
        $params['warehouse_id'] = $warehouseId;
    }
    if ($statusFilter) {
        $query .= " AND i.stock_status = :status";
        $params['status'] = $statusFilter;
    }

    $query .= " ORDER BY (i.quantity_on_hand - i.reorder_point) ASC LIMIT :limit";

    $stmt = $pdo->prepare($query);
    foreach ($params as $k => $v) {
        $stmt->bindValue(":{$k}", $v);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll();

    echo json_encode([
        'success' => true,
        'count' => count($rows),
        'inventory' => $rows
    ]);
    exit;
}

// 2. STOCK DEDUCTION & AUTOMATED ROP TRIGGER
if ($method === 'POST' && ($action === 'deduct' || $action === 'adjust')) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    $productId = (int)($input['product_id'] ?? 0);
    $warehouseId = (int)($input['warehouse_id'] ?? 0);
    $deductQty = (int)($input['quantity'] ?? 10);

    if ($productId <= 0 || $warehouseId <= 0 || $deductQty <= 0) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Invalid parameters. product_id, warehouse_id, and positive quantity required.'
        ]);
        exit;
    }

    try {
        $pdo->beginTransaction();

        // 1. Fetch current inventory and product details with locking
        $stmt = $pdo->prepare("
            SELECT 
                i.id, i.quantity_on_hand, i.reorder_point, i.economic_order_qty, i.stock_status,
                p.sku, p.name AS product_name, p.unit_price, p.daily_demand_rate, p.supplier_id,
                w.code AS warehouse_code, w.name AS warehouse_name,
                s.name AS supplier_name, s.lead_time_days
            FROM inventory i
            JOIN products p ON i.product_id = p.id
            JOIN warehouses w ON i.warehouse_id = w.id
            JOIN suppliers s ON p.supplier_id = s.id
            WHERE i.product_id = :pid AND i.warehouse_id = :wid
            FOR UPDATE
        ");
        $stmt->execute(['pid' => $productId, 'wid' => $warehouseId]);
        $inv = $stmt->fetch();

        if (!$inv) {
            $pdo->rollBack();
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Inventory record not found for this product/warehouse combination.']);
            exit;
        }

        $prevQty = (int)$inv['quantity_on_hand'];
        $newQty = max(0, $prevQty - $deductQty);
        $rop = (int)$inv['reorder_point'];
        $eoq = (int)$inv['economic_order_qty'];

        // Determine new Stock Status
        $newStatus = 'OPTIMAL';
        if ($newQty <= 0) {
            $newStatus = 'OUT_OF_STOCK';
        } elseif ($newQty < ($rop * 0.7)) {
            $newStatus = 'CRITICAL_REORDER';
        } elseif ($newQty <= $rop) {
            $newStatus = 'LOW_STOCK';
        }

        // Update inventory record
        $upd = $pdo->prepare("
            UPDATE inventory 
            SET quantity_on_hand = :new_qty, stock_status = :status, updated_at = NOW() 
            WHERE id = :id
        ");
        $upd->execute(['new_qty' => $newQty, 'status' => $newStatus, 'id' => $inv['id']]);

        // Evaluate Reorder Point Breach & Automated PO Generation
        $poCreated = null;
        if ($newQty <= $rop) {
            // Check if there is already an active Draft or Issued PO for this product at this warehouse
            $checkPo = $pdo->prepare("
                SELECT po.id, po.po_number, po.status 
                FROM purchase_orders po
                JOIN po_items poi ON po.id = poi.po_id
                WHERE poi.product_id = :pid 
                  AND po.warehouse_id = :wid 
                  AND po.status IN ('Draft', 'Issued')
                LIMIT 1
            ");
            $checkPo->execute(['pid' => $productId, 'wid' => $warehouseId]);
            $existingPo = $checkPo->fetch();

            if (!$existingPo) {
                // Auto-create a Draft PO using EOQ
                $orderQty = max($eoq, 50);
                $unitPrice = (float)$inv['unit_price'];
                $totalAmount = round($orderQty * $unitPrice, 2);
                $poNumber = 'PO-AUTO-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -5));
                $expectedDelivery = date('Y-m-d', strtotime('+' . (int)$inv['lead_time_days'] . ' days'));

                $createPo = $pdo->prepare("
                    INSERT INTO purchase_orders 
                    (po_number, supplier_id, warehouse_id, status, total_amount, trigger_type, expected_delivery_date)
                    VALUES (:po_num, :sup_id, :wh_id, 'Draft', :amount, 'AUTOMATED_ROP', :delivery)
                ");
                $createPo->execute([
                    'po_num' => $poNumber,
                    'sup_id' => $inv['supplier_id'],
                    'wh_id' => $warehouseId,
                    'amount' => $totalAmount,
                    'delivery' => $expectedDelivery
                ]);
                $newPoId = (int)$pdo->lastInsertId();

                // Insert PO line item
                $addItem = $pdo->prepare("
                    INSERT INTO po_items (po_id, product_id, quantity, unit_price, subtotal)
                    VALUES (:po_id, :pid, :qty, :price, :subtotal)
                ");
                $addItem->execute([
                    'po_id' => $newPoId,
                    'pid' => $productId,
                    'qty' => $orderQty,
                    'price' => $unitPrice,
                    'subtotal' => $totalAmount
                ]);

                $poCreated = [
                    'po_id' => $newPoId,
                    'po_number' => $poNumber,
                    'ordered_quantity' => $orderQty,
                    'total_amount' => $totalAmount,
                    'expected_delivery_date' => $expectedDelivery,
                    'supplier_name' => $inv['supplier_name']
                ];
            }
        }

        $pdo->commit();

        // 3. Webhook broadcast to Node.js WebSocket Service
        $alertPayload = [
            'product_id' => $productId,
            'sku' => $inv['sku'],
            'product_name' => $inv['product_name'],
            'warehouse_id' => $warehouseId,
            'warehouse_code' => $inv['warehouse_code'],
            'previous_qty' => $prevQty,
            'deducted_qty' => $deductQty,
            'current_qty' => $newQty,
            'reorder_point' => $rop,
            'stock_status' => $newStatus,
            'auto_po' => $poCreated
        ];

        // Notify Node.js event hub
        $webhookResult = notifyNodeService('inventory:alert', $alertPayload);

        if ($poCreated) {
            notifyNodeService('po:status_change', [
                'po_id' => $poCreated['po_id'],
                'po_number' => $poCreated['po_number'],
                'warehouse_code' => $inv['warehouse_code'],
                'supplier_name' => $inv['supplier_name'],
                'status' => 'Draft',
                'action' => 'AUTO_CREATED_BY_ROP',
                'total_amount' => $poCreated['total_amount']
            ]);
        }

        echo json_encode([
            'success' => true,
            'message' => 'Stock successfully deducted and ROP evaluated.',
            'inventory' => [
                'inventory_id' => $inv['id'],
                'product_id' => $productId,
                'sku' => $inv['sku'],
                'warehouse_id' => $warehouseId,
                'previous_quantity' => $prevQty,
                'new_quantity' => $newQty,
                'reorder_point' => $rop,
                'economic_order_qty' => $eoq,
                'stock_status' => $newStatus
            ],
            'automated_po' => $poCreated,
            'webhook_dispatched' => $webhookResult['dispatched']
        ]);
        exit;

    } catch (Exception $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Deduction failed: ' . $e->getMessage()]);
        exit;
    }
}

http_response_code(400);
echo json_encode(['success' => false, 'error' => 'Unsupported action.']);
